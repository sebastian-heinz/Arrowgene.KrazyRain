KRAZY RAIN - OFFLINE PATCH
==========================
You can change your nickname by utilizing a HEX-Editor and search for "arrowgene.net" and overwrite it with your desired name.


I added the branding to promote my services as compensation for the time spend on developing this patch.
It would make me happy if you spread the files in its original form, however you are free to do or sail as you wish pirate!

Thank you very much, enjoy your time!
==========================
Created by: 
Nothilvien 
https://arrowgene.net
https://discord.com/invite/dNhx9tH
==========================
